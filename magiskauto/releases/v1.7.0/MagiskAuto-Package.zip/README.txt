MagiskAuto - Magisk patcher for Google Pixel 6a and Samsung Galaxy Note 10
=========================================================================

WHAT'S IN THIS PACKAGE
  MagiskAuto.exe    The program. Double-click it.
  _internal         Files MagiskAuto.exe needs. Keep this folder next to it.
  Magisk-*.apk      The official Magisk app. It's used for patching and can be
                    installed on the phone. MagiskAuto finds it automatically.
  LICENSES.txt      Licence information for Magisk.

Everything else is set up for you the first time you run MagiskAuto:
  - adb and fastboot (Google's platform-tools): just press Enter to accept
  - Pixel 6a: the Google USB Driver (Windows asks for admin permission)
  - Note 10: the Samsung USB Driver, downloaded from Samsung's own site and
    checked for Samsung's digital signature before it's run
  - Note 10: Odin is found automatically if you already have it (also inside
    an Odin zip in your Downloads folder). If not, MagiskAuto tells you where
    to get it. At the end, MagiskAuto works Odin for you.

BEFORE YOU START
  - The phone's bootloader must be UNLOCKED. Unlocking ERASES the phone.
  - US/Canada Note 10 models (SM-N970U/U1/W) cannot be rooted.
  - Turn on USB debugging on the phone: Settings > About phone > tap
    "Build number" 7 times, then Developer options > USB debugging.

HOW TO USE IT
  1. Unzip this package into a normal folder, such as Desktop or Downloads.
  2. Plug in the phone and double-click MagiskAuto.exe.
  3. Choose your phone and follow the steps. MagiskAuto shows the link to
     the right firmware for your phone. When it's downloaded, drag the file
     into the window.
  4. Results are saved in the "magisk-output" folder.

  Only want to prepare the PC?  Run:  MagiskAuto.exe --setup

GALAXY NOTE 10: FLASHING WITH ODIN
  The Note 10 can't be flashed from the command line like the Pixel. It
  needs Samsung's flashing tool, Odin. Samsung doesn't publish Odin, so only
  unofficial copies exist. MagiskAuto won't download one automatically:
  save an Odin zip (e.g. Odin3 v3.14.4, from XDA Developers) to your Downloads
  folder and MagiskAuto finds and unzips it.

  MagiskAuto then flashes for you, after you confirm: it restarts the phone
  into download mode, opens Odin, loads BL, AP (the patched file), CP and CSC,
  unticks Auto Reboot, clicks Start and waits for PASS. Odin may need admin
  rights: then a second MagiskAuto window opens as admin to do this part.
  CSC is used the first time (this WIPES the phone); when re-patching a phone
  that already has Magisk, HOME_CSC is used to keep your data.

  When it says PASS: hold Vol Down + Power, then right away hold
  Vol Up + Power, and let go at the "bootloader unlocked" warning. Always
  start the phone that way (Vol Up + Power) to have root.

  If the automatic flashing can't finish, MagiskAuto stops (it never clicks
  Start unless everything checked out) and shows the steps to do it by hand:
    0. Download mode: power off, hold Vol Up + Vol Down, plug in USB, Vol Up.
    1. Load BL, CP and CSC from "magisk-output", and magisk_patched-*.tar in AP.
    2. In Options, untick "Auto Reboot", then press Start.

PIXEL 6a
  MagiskAuto can flash the patched file for you. If it waits at "Waiting for
  fastboot", let it install the Google USB Driver, or try another cable or
  USB port.

More help and new versions: https://akkainc.github.io/magiskauto/
